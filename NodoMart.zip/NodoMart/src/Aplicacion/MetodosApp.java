
package Aplicacion;


public interface MetodosApp {
    
    //Molde para metodos de la clase "BaseDeDatos"
   
  
    public void cargarBaseDatosServicios();

     
}
